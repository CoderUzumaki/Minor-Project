# Project handoff

Updated **9 November 2026 (Asia/Calcutta)**. Delivery target: **1 December 2026**.
Authoritative scope: [Research_Plan.md](Research_Plan.md).

## Status

Implemented: data preparation, overlap audit, causal clean/attacked replay,
residual/CUSUM baseline, heuristic trust and conservative fusion, offline display,
metrics, reproducibility checks, and self-contained Colab notebook.

**The full research project is not complete. No GRU/GNN has been trained.** The
initial baseline has many false alerts and low recall; it is not a validated defense.

## Entry points

| File | Purpose |
|---|---|
| `scripts/replay_core.py` | Annotation-free local Kalman trackers, detector, trust and CI fusion |
| `scripts/run_replay.py` | Grouped splits, extraction, offline injection, four runs and evaluation |
| `scripts/infer_replay.py` | Standalone inference from canonical reports only |
| `scripts/verify_replay.py` | Exact inference reproduction without annotations/labels |
| `scripts/render_replay.py` | Offline HTML, measured report and comparison figure |
| `scripts/build_notebook.py` | Rebuild both portable notebooks from current source |
| `data_manifests/mini_splits.json` | Frozen recording-grouped pilot splits |
| `notebooks/02_causal_radar_replay.ipynb` | Colab setup, preparation, audit, replay and results ZIP |
| `outputs/replay_pilot/demo.html` | Clean / attacked / protected playback display |
| `outputs/replay_pilot/REPORT.md` | Actual results and limitations |
| `DEMO_GUIDE.md` | Presentation walkthrough and claim boundaries |

## Run locally

```powershell
.venv\Scripts\python -m pytest -q --basetemp=outputs/test_tmp
.venv\Scripts\python -u scripts/run_replay.py
.venv\Scripts\python -u scripts/verify_replay.py
.venv\Scripts\python scripts/build_notebook.py
```

Open `outputs/replay_pilot/demo.html` in a desktop browser; it embeds its data and
needs no server. Keep the output folder for linked reports and figures. The first
local extraction plus four runs took about 63 seconds (not a runtime guarantee).

For Colab, upload notebook 02, choose CPU, Run all, and download the results ZIP.
The new notebook has not yet been run in a fresh remote Colab runtime. The embedded
pipeline was exercised locally. Initial raw download is still about 4.17 GB.

## Scientific boundaries

1. The earlier feasibility audit examined all mini scenes. The new manifest groups
   `log_token` recordings before replay extraction/injection. These are pilot splits,
   not an untouched final benchmark. Replay used only a training scene.
2. The default demo uses the longest >=4s audited training pair episode, selected
   deterministically without inspecting detector success.
3. Each sensor sweep is consumed once in time order, using its calibration and ego
   pose. No future annotation velocities enter inference. Reception time is null
   where unavailable.
4. Default radar validity filtering and a 60m sensor-range limit precede position
   DBSCAN (`eps=2m`, `min_samples=1`). Centroids are reflection centers, not semantic
   object centers. Singletons/clutter remain a documented frontend weakness.
5. `inputs/` contains annotation-free reports. `evaluation/` contains labels,
   reference annotations and the injection manifest. `runs/` contains decisions.
   Original recordings and the clean exported input are preserved.
6. Injection is **after shared clustering, before tracking**, at the position-report
   boundary. This refines the plan's generic diagram; it is not a raw-point/RF attack.
7. The offline injector selects centroids exclusively inside the latest annotation
   box (+0.5m), excluding ambiguous memberships. This is a target-association proxy,
   especially imperfect for moving targets. Two streams share a displacement process.
8. Ground-truth boxes, target-following camera and attack timing are offline display
   aids only. Inference receives no annotation IDs, labels or reference trajectory.

## Implemented baseline

- Position-only constant-velocity state `[x,y,vx,vy]`, with Hungarian gated matching.
  Velocity comes from past positions. Doppler is not incorrectly treated as a full
  Cartesian velocity measurement. Three accepted hits confirm a track.
- Innovation/CUSUM thresholds, process noise and centroid uncertainty are explicit
  **pilot heuristics**, not calibrated parameters. Trust is not a probability.
- New/unmatched reports remain unknown and monitored. Large shifts can evade
  association and initialize new tracks. Missing evidence alone does not lower trust.
- Protection rejects flagged updates, coasts at most 0.8s and inflates covariance
  with smoothed trust. Expiry/reinitialization is a failure mode, not truth recovery.
- Complete-link spatial groups with at most one track per sensor; equal-weight
  covariance intersection avoids treating estimates as independent evidence.
- Single-source/degraded/multi-source-unverified statuses. Multiple agreeing sensors
  do not establish truth. Visibility and persistent fused identities are unfinished.
- Four paired runs: clean baseline, clean protected, attacked baseline, attacked
  protected. All use the same frontend and fusion rule.

## Initial measured results

Training scene `scene-0553`, 1,348 radar sweeps; selected target is a trailer. This is
not evidence of moving-target generalization. A shared 4m offset alters 320 reports
across the two rear radars during the recorded six-second injection window.

| Report-level measure | Attacked baseline | Attacked protected |
|---|---:|---:|
| True positives | 4 | 41 |
| False positives | 3,088 | 2,007 |
| False negatives | 316 | 279 |
| Recall | 1.25% | 12.81% |
| Precision | 0.13% | 2.00% |
| First detected altered-report delay | 3.776s | 0.725s |

These are poor results, preserved for diagnosis. Clean protection also raises missed
target-frames from 570 to 607 while reducing unmatched hypotheses. A lower protected
GOSPA alone cannot be attributed to attack mitigation: compare each attacked branch
to its own clean branch. One detected event is not an event-detection benchmark.

Evaluation includes all eligible annotations and emitted hypotheses. Conditional
RMSE uses 4m gated matching; GOSPA uses `(p=2,c=10m,alpha=2)`. Background clutter is
retained. Per-report alerts are not independent attack events. Timing currently
covers local updates only, excluding extraction, fusion, display and end-to-end cost.

## Checks and limitations

- **16 tests passed**: prior audit geometry plus causal prefix invariance, duplicate
  sweep rejection, uncertainty, stale/rejected tracks, unmatched reports, missing
  evidence, CI correlation behavior, known-answer metrics, repeatable injection and
  recording-grouped split immutability.
- `verify_replay.py` reproduces exact frames/decisions in an isolated directory with
  only inference scripts and attacked input. Timing is excluded as nondeterministic.
  Its result is `outputs/replay_pilot/checks/inference_isolation.json`.
- Comparison PNG rendered and visually inspected; generated JavaScript syntax
  checked with Node. **Browser layout/playback is not visually verified**: localhost
  was unreachable from the in-app browser, and Computer Use stopped because URL-policy
  enforcement is unsupported for the available Windows browser.
- The `.venv` has no pip module (created through uv). No package installation was
  needed locally. `uv --cache-dir .uv-cache pip check --python .venv/Scripts/python.exe`
  checked 34 packages successfully. Keep uv's cache inside the workspace on this
  sandboxed Windows host, or use the notebook bootstrap.
- New Colab notebook remote execution is unverified; do not claim otherwise.

## Next work, in order

1. **Nov 10–12: frontend and baseline diagnosis.** Inspect overlap candidates and
   strict-box/two-return sensitivity; examine cluster merges, clutter and association
   switches. Improve target-like tracking with causal inputs, calibrate noise and
   thresholds using train/validation only, save the configuration and measure clean
   false-alert behavior before adding graph learning.
2. **Dataset gate:** mini offers 149 sustained pair episodes but only two triple
   episodes. Expand the real subset or narrow recovery claims. Inspect moving targets
   separately; never manufacture overlap.
3. **Experiment matrix:** single-stream bias, coordinated gradual drift, independent
   two-stream perturbations, benign calibration/timing stresses, then suppression
   with predicted observation slots and visibility uncertainty.
4. **Nov 13–16: learning.** Cache causal track features; implement/train node-only GRU
   then compact temporal graph model. No annotation IDs in graph construction.
   Preserve unmatched candidates and calibrate probabilities on validation only.
5. **Fusion/evaluation:** robust-consensus comparison, visibility/ambiguity handling,
   persistent fused IDs, velocity/identity metrics, probability calibration,
   end-to-end latency and multiple seeds.
6. **Nov 17–24: frozen experiments.** Larger independent scene manifest, held-out
   attack families, graph-vs-GRU and trust-vs-no-trust ablations, scene-level paired
   uncertainty estimates. Do not repeatedly tune on final test recordings.
7. **Nov 25–Dec 1: delivery.** Verify browser playback, record the demo, complete
   paper/presentation, and reproduce in a fresh environment. Apply the research
   plan's scope-reduction dates if baseline/GNN milestones are missed.

After each session update this document, rebuild notebooks after source edits, log
checks actually run, and retain measured failures. Never present the pilot, software
corruptions, heuristic trust or an untrained graph model as validated radar security.
