# Coordinated radar attack detection and trust-aware fusion

Research and delivery plan prepared 7 November 2026. Deadline: 1 December 2026. Team: two people. Compute: free Google Colab. No radar boards or laboratory access.

## 1. Decision and defensible scope

Build a **replay-based research prototype for detecting coordinated manipulation of automotive radar reports and limiting its effect on multi-object tracking**. Use actual recorded radar measurements, a controlled software attack injector, a small temporal graph neural network, and conservative trust-aware fusion. Deliver an executable demonstration, reproducible experiments, and a submission-ready paper by 1 December. Peer-reviewed acceptance by that date cannot be promised.

Recommended working title:

> Coordinated Radar-Report Attack Detection with Temporal Graph Learning and Trust-Aware Fusion: A Reproducible Evaluation on Recorded Driving Data

The original broad title can remain the project title. The paper title should identify the actual attack surface and validation level. Automotive radar is the achievable experimental domain. Air traffic and maritime radar are motivation and architectural comparisons, not validated deployment domains.

This is a research plan, not a completed experimental study. No proposed detector has been trained, dataset replayed, or performance measured in this work. Numerical settings below are proposed experimental choices, not results. The six supplied PDFs were reviewed, including methods and relevant evaluation sections; selected pages were also visually checked. External primary research, dataset documentation, and official operational reports were searched. This is a focused literature review, not an exhaustive systematic review.

Three evidence categories must remain separate:

| Evidence | What it supports | What it does not support |
|---|---|---|
| Real recorded benign radar data | Real sensor noise, clutter, geometry, and traffic conditions | Real malicious attack measurements |
| Controlled modifications of those reports | Measured performance against the stated data-manipulation model | Feasibility of producing every modification over the air |
| Fully synthetic geometry experiments | Exact ground truth and controlled observability studies | Performance of operational radar hardware |

Randomness is appropriate for reproducible Monte Carlo experiments, sampling, and training initialization. Fabricating final accuracy values is not. Every reported outcome must come from a saved execution, with its configuration, source data, and seed.

## 2. What the supplied papers contribute

All six originals are in `Research Papers/`. Page references below refer to PDF pages, with printed pagination where useful.

| Supplied paper | Evidence and method | Use in this project | Limitation for the proposed claim |
|---|---|---|---|
| Calatrava, Tang, Closas, *Advances in Anti-Deception Jamming Strategies for Radar Systems: A Survey*, DOI 10.1109/MAES.2025.3588477; supplied issue April 2026 | Taxonomy of prevention, detection, signal-domain mitigation, and measurement-domain mitigation. Distributed radar and AI discussion on PDF pp. 18–21 | Main taxonomy and citation trail; particularly references 34, 54, 56, 58, and 60 | A survey does not establish the effectiveness of our detector. It already discusses cooperative deception and graph-based recognition; avoid broad first-ever claims |
| Xie et al., *A Radar System With Adaptive Waveform Selection Against Dynamic Spoofing Attacks*, DOI 10.1109/TAES.2024.3499901; April 2025 issue | Authentication/detection followed by waveform selection; simulations and hardware measurements using two IWR1843 radars; PDF pp. 7–8 distinguish the experiments | Motivation for a detect-then-mitigate pipeline and eventual waveform-level extension | Requires waveform control and RF validation. A point-cloud replay cannot reproduce or validate the waveform defense |
| Kumuda et al., *Multitarget Detection and Tracking by Mitigating Spot Jammer Attack in 77-GHz mm-Wave Radars*, DOI 10.1109/JSEN.2022.3227012; 2023 | IWR1642 victim, AWR1642 interferer, DCA1000 capture; four CFAR variants, clustering, EKF tracking; experimental setup and results on PDF pp. 10–11 onward | Practical reference pipeline and tracking-centric evaluation | One victim radar with a spot interferer, not a colluding network. Its “GNN” means **global nearest neighbor association**, not graph neural network |
| Bi et al., *Detection and Mitigation of Position Spoofing Attacks on Cooperative UAV Swarm Formations*, DOI 10.1109/TIFS.2023.3341398; 2024 | Geometric feasibility, semidefinite relaxation, and malicious-node identification; simulation includes collusion | Shows why multiple agreeing reports can frame an honest node; motivates geometric constraints | UAV localization assumptions and distance observations do not transfer automatically to radar target tracking; no radar hardware validation |
| Yamasaki et al., *Detection and Mitigation of Sensor-Data Tampering Attacks for Leader–Follower CACC Systems with Multiple Inter-Vehicle Distance Sensors*, DOI 10.1109/MECATRONICS-REM67547.2025.11349406; supplied 2025 proceedings | Model-based tamper detection observer and redundant measurements; ten-vehicle simulation; conclusion leaves modeling errors for future work | Strong simple baseline idea: prediction residuals and redundant sensing | Specified platoon model and attack cases; not general multi-radar coordinated deception; results are simulated |
| Li et al., *RADAR: Run-time Adversarial Weight Attack Detection and Accuracy Recovery* | Checksums and recovery for neural-network weight bit flips in memory | Optional model-integrity background | **RADAR is an acronym, not a radar-sensor defense.** Exclude it from the core radar-method comparison |

Do not copy published percentages into a target-results table. Different threat models, sensors, and metric denominators make such comparisons misleading.

## 3. Closest additional work and research gap

The following are especially important before writing a novelty claim:

1. **Distributed radar under registration errors.** Zhao, Yi, and Liu use received-signal correlation while accounting for registration uncertainty. This is relevant to distinguishing deception from misalignment, but access to received signals differs from access to processed reports. [Primary article](https://www.mdpi.com/1424-8220/22/19/7216).
2. **Collaborative false targets already have radar-specific defenses.** Yang et al. combine local filtering and consensus covariance intersection; their collaborative-deception treatment uses passive radar information. This makes an independent reference an explicit architectural resource. [Primary article](https://ietresearch.onlinelibrary.wiley.com/doi/10.1049/rsn2.12371).
3. **Coordinated multijammer research already exists.** Sun et al. study coordinated deception-jamming power scheduling against distributed radar systems. Its existence rules out claiming coordinated radar deception is a newly discovered problem. [University repository](https://arpi.unipi.it/handle/11568/1278272).
4. **Trust-aware fusion already exists.** MATE estimates trust distributions and uses them in fusion. Its discussion explicitly identifies coordinated false reports and sparse overlapping coverage as difficulties. It is a key conceptual and experimental baseline; use the available preprint as such and verify publication/code status before submission. [Authors’ full text, especially §9](https://arxiv.org/html/2503.04954v1).
5. **Radar-camera attack detection already exists.** Alkanat and Pandharipande, IV 2025, evaluate detection/localization using real data with simulated spoofing. The published abstract reports F1 of 0.93 for false-positive and 0.82 for false-negative attacks. These are their results, not comparable targets for ours. [University publication record](https://research.tue.nl/en/publications/deep-sensor-fusion-for-detection-and-localization-of-automotive-r/).
6. **Graph learning itself is not sufficient novelty.** The supplied survey cites Zhu et al., *Radar Deception Jamming Recognition Based on GCN and Transformer*, ICSIDP 2024. Retrieve the primary full text before making a fine-grained comparison. Graph-based physical-layer spoofing detection also exists in wireless communications, a different sensing problem. [Authors’ preprint](https://arxiv.org/abs/2401.08220).
7. **An additional trust-fusion paper requires closer review.** *Cyber-Resilient Perception: Safeguarding Autonomous Vehicles With Trust-Aware Sensor Fusion*, DOI 10.1109/SR.2025.3562156, is closely related. The publisher record was found, but full methods were not accessible in this review. Do not assert a gap it might already address. [Publisher record](https://ieeexplore.ieee.org/document/10971200/).

**Candidate contribution, subject to verification:** a reproducible evaluation of whether visibility-aware temporal graph features improve coordinated radar-report attack detection and downstream tracking, especially under calibration errors, limited overlap, and attacks withheld during training. Include calibrated trust, a conservative fallback, and documented failure boundaries. A well-designed benchmark and a negative result can be scientifically useful; the GNN must earn its place against simpler methods.

## 4. Architecture landscape and operational uses

Do not conflate three independent classifications: physical sensor arrangement, where processing occurs, and the stage at which data are fused.

| Architecture | Flow and representative use | Strength | Main shortcomings under attack |
|---|---|---|---|
| Single monostatic radar | Co-located transmitter/receiver; local detection and tracking | Simple, low communication demand | One observation source can be deceived; little independent corroboration |
| Multiple monostatic radars | Several independently sensing radars on a vehicle or distributed sites | Different viewpoints and coverage | Overlap may be poor; common software, timing, or pose can create shared failures |
| Bistatic/multistatic and distributed MIMO | Separated transmit/receive geometries | Additional propagation constraints and diversity | Synchronization, registration, bandwidth, association, and waveform access requirements |
| Centralized fusion | Measurements/features sent to one fusion processor | Global evidence and straightforward experiment logging | Fusion center is a critical dependency; input corruption can poison the global estimate |
| Decentralized/consensus fusion | Local tracks exchanged among nodes | No sole processing node; scalable local operation | Colluding nodes, uncertain cross-correlations, network partitions, repeated information |
| Hierarchical fusion | Local processing, then regional/global fusion | Practical bandwidth/compute balance | Local errors propagate; lost low-level evidence may be impossible to recover |
| Heterogeneous fusion | Radar combined with camera, LiDAR, inertial or navigation observations | Different sensing mechanisms can provide independent evidence | Independence is conditional; shared GNSS/time/pose can corrupt multiple modalities together |
| Cognitive radar | Sensing results alter waveform or resource allocation | Can change how evidence is acquired | More hardware/control complexity; not achievable through recorded point clouds alone |

Fusion stage is another choice: **early** fusion combines raw signals/measurements, **middle** fusion combines features, and **late** fusion combines detections or tracks. Early fusion preserves evidence but demands access and calibration; late fusion is easier to prototype but can hide the origin of errors. The proposed prototype uses local track/report features and late fusion.

Operational evidence: EUROCONTROL ARTAS combines radar and other surveillance reports into an air-traffic picture, demonstrating that multi-source tracking is deployed infrastructure. Its public description does not establish that it uses our proposed GNN or that it suffered a coordinated compromise. [EUROCONTROL ARTAS](https://www.eurocontrol.int/product/artas).

Automotive multi-radar sensing is directly represented by the five-radar nuScenes recording platform and four-radar RadarScenes platform. These are concrete experimental platforms, not proof of a particular production security mechanism. [nuScenes paper](https://openaccess.thecvf.com/content_CVPR_2020/papers/Caesar_nuScenes_A_Multimodal_Dataset_for_Autonomous_Driving_CVPR_2020_paper.pdf), [RadarScenes](https://radar-scenes.com/).

The technical principle behind conservative track fusion is that different estimates can share information. Covariance intersection addresses unknown correlations when its input estimates are consistent; it does not make malicious inputs trustworthy. [Research article](https://www.sciencedirect.com/science/article/abs/pii/S0921889006001436).

## 5. Incidents and experimental case studies

### A. Black Sea, June 2017: GNSS spoofing affecting multiple ships

**Who/where/when:** C4ADS documents reports including the merchant vessel Atria near Gelendzhik, Russia, in June 2017. **What/how:** onboard navigation indicated a false inland airport position; other vessels reported similar disruption. **Result/response:** an operational navigation integrity problem and a US maritime interference advisory. C4ADS analyzes a wider pattern associated with Russian locations and protected facilities, but this does not identify the individual operator of every event. [C4ADS report and supporting report PDF](https://c4ads.org/reports/above-us-only-stars/).

**Research lesson, our inference:** many affected receivers can share one corrupted source. Agreement is not independence. This is GNSS evidence, not a verified coordinated attack on radar echoes. Do not describe the event as a radar-network compromise or claim that a GNN would have prevented it.

### B. Tartu, Estonia, April–June 2024: operational disruption and concrete recovery

**Who/when/where:** Finnair suspended Tartu flights from 29 April through 31 May after GPS interference disrupted approaches. **What/how:** reliance on GPS-dependent approach procedures made interference operationally consequential. **Response/result:** an alternative approach that did not require GPS was introduced; flights resumed on 2 June. The airline statements establish the disruption and recovery, not a forensic identification of the transmitter. [Finnair suspension statement](https://news.cision.com/finnair/r/finnair-suspends-flights-to-tartu-for-a-month%2Cc3970152), [resumption statement](https://news.cision.com/finnair/r/finnair-resumes-flights-to-tartu%2Cc3982230).

**Research lesson, our inference:** mitigation should include a useful independent fallback and a service-degradation state. An alarm alone is incomplete. The European Commission separately reported the ICAO Assembly's attribution of regional harmful GNSS interference to Russia in October 2025; this is regional attribution, not proof of the operator of these individual flights' interference. [Official statement](https://transport.ec.europa.eu/news-events/news/eu-welcomes-un-aviation-agencys-condemnation-russia-undermining-global-aviation-safety-2025-10-03_en).

### C. Baltic maritime navigation, official 2026 notice

The Swedish Maritime Administration's notice 20041(T), published 22 April 2026 and included in its 20 May bulletin, reports recurring GNSS disruption and observed interference in radar and AIS. It recommends independent position checks and awareness of onboard GNSS dependencies. **Unknown:** exact transmitter, mechanism, coordination, affected radar processing layer, and attack success statistics. This is evidence of reported system interference, not proof of synchronized manipulation of several independent radar front ends. [Official bulletin, p. 3](https://ufs.sjofartsverket.se/pdf/2026/1119EN.pdf).

A separate December 2025 agency announcement described adding radar beacons at ten lighthouse sites to support navigation during GPS disruption. Treat it as an announced resilience measure, not evidence that a particular radar attack was defeated. [Swedish Maritime Administration](https://www.sjofartsverket.se/en/about-us/news-and-press/news/tried-and-tested-technology-ensures-safe-maritime-navigation-during-gps-disruptions/).

### D. MadRadar, Duke University / NDSS 2024: controlled radar attack demonstration

**Who/what:** Hunt, Angell, Qi, Chen, and Pajic developed a black-box FMCW radar attack framework. **How at a high level:** it estimates victim configuration and manipulates detections. **Result:** controlled physical prototype experiments demonstrate adding, removing, and moving detections. This is direct radar-security evidence, but a laboratory research demonstration rather than a documented criminal incident or deployed multi-radar compromise. [NDSS primary publication](https://www.ndss-symposium.org/ndss-paper/madradar-a-black-box-physical-layer-attack-framework-on-mmwave-automotive-fmcw-radars/).

**Research lesson:** insertion, suppression, and translation are justified report-level stress categories. It does not follow that arbitrary software edits are RF-realizable. Our mitigation is a proposal to evaluate, not a demonstrated defense against MadRadar hardware.

### E. Supplied hardware studies

The spot-jammer paper and adaptive-waveform paper provide physical experimental evidence for interference effects and countermeasures under their setups. Their results are valuable engineering references. They neither validate a temporal GNN nor establish a public coordinated multi-radar attack dataset.

**Evidence conclusion:** this review did not establish a publicly documented, fully attributed field incident with synchronized raw data proving coordinated deception of multiple radar sensors and quantifying the subsequent mitigation. That absence in this review is not proof that such incidents never occur. Do not fill this gap with speculative military anecdotes.

## 6. Dataset decision and feasibility gate

### Primary: nuScenes radar subset

Prefer nuScenes for the main prototype because it provides five radar streams, calibration/ego-pose information, and annotated 3D objects. Use the mini release to debug ingestion, then selected train/validation scenes for the actual experiment. Mini-only results should be described as a pilot, not a robust publication benchmark. Ground-truth boxes are evaluated at labeled keyframes; do not claim measured ground truth at every intermediate radar timestamp. [Official tutorial](https://www.nuscenes.org/tutorials/nuscenes_tutorial.html).

The first two days must check access and terms, storage, stream decoding, annotation timestamps, and **actual multi-radar coverage of the same object**. Five installed sensors do not mean five independent observations per target. Produce a coverage histogram: eligible objects seen by 1, 2, 3, or more sensors within a causal time window. Coverage measurement can use labels offline; runtime features cannot.

Select enough independent scenes to support uncertainty estimates within compute limits, provisionally aiming for approximately 100–200 scenes after the pilot. This is a capacity target, not a statistical guarantee or a selected final sample size. Save exact scene IDs and report the distribution of usable overlaps. If access or useful overlap is inadequate by 10 November, move to RadarScenes and narrow the claims immediately.

### Fallback: RadarScenes

RadarScenes has four sensors and sequential measurements with sensor IDs, timestamps, Doppler, RCS, mounting calibration, and odometry. Its scene unit is one sensor measurement, so simultaneous fusion requires careful temporal alignment. It has 158 sequences. [Official structure](https://radar-scenes.com/dataset/structure/).

Its labels describe moving-object radar points and track identity; they are not independent, continuous, high-precision physical target trajectories. Track IDs can change after stopping or occlusion. Therefore, report recovery of recorded clean observations and point/track association results separately from any physical-position claim. Do not call a clean radar centroid exact ground truth. [Official labeling](https://radar-scenes.com/dataset/labeling/).

### Optional only

The Radar Ghost Dataset provides naturally occurring multipath examples useful for benign false-alarm checks. It is not an attack dataset. [Primary paper, IROS 2021; arXiv version posted 2024](https://arxiv.org/abs/2404.01437).

View-of-Delft provides one front radar alongside other modalities, so it is not the default for multi-radar collusion. Access also has eligibility restrictions. [Official dataset](https://intelligent-vehicles.org/datasets/view-of-delft/).

No hardware experiment belongs in the December deliverable. No claim of RF-domain validation, interference power measurements, or live vehicle safety should appear in the paper.

## 7. Threat model and limits

The principal adversary alters up to k radar-report streams before the trusted fusion process, including synchronized insertion, removal, or displacement of selected object measurements. The experiment controls the reports of compromised sensors; it does not claim the same capabilities for an RF-only attacker. Stream identity, acquisition timestamps, calibration, ego-pose, model code, and logger are initially trusted. Separate stress tests deliberately weaken calibration/pose assumptions.

Define coordination operationally: at least two manipulated streams share a false object trajectory, displacement process, or suppression objective. Independent simultaneous noise on two sensors is a separate comparator, not automatically a coordinated deception case.

Primary detection granularity is **sensor–object–time reliability**. A sensor that reports one manipulated target may still provide useful measurements of others. Aggregate sensor-level alerts are secondary. For suppression, create predicted observation slots so a missing measurement can be assessed. Missing observations outside field of view or under uncertain visibility must not automatically lower trust.

Known limits:

- With one observing sensor, a plausible false report may be indistinguishable from a genuine target.
- With two disagreeing sensors, the system may detect conflict without identifying the honest source.
- A coordinated false trajectory consistent with every available measurement, prediction, and independent reference cannot generally be distinguished using those same observations.
- A healthy sensor seeing an unrelated region does not resolve ambiguity for the attacked target.
- Shared ego-pose or time errors can mimic coordination. Adding more same-platform sensors does not remove that dependency.
- Anomaly evidence cannot establish malicious intent; use “suspected corruption” rather than claiming attacker attribution.

Sparse-observability results in secure state estimation formalize related recovery limits for specified linear systems. Do not apply a simple majority formula as a guarantee for nonlinear, asynchronous multi-target radar. [Primary secure-state-estimation paper](https://arxiv.org/abs/1510.02462).

## 8. Complete proposed process flow

```mermaid
flowchart TD
    A[Recorded radar streams] --> B[Validate IDs and timestamps; transform coordinates]
    P[Calibration and ego pose] --> B
    B --> C[Controlled report injector: evaluation branch]
    C --> D[Per-sensor clustering and causal local trackers]
    D --> E[Candidate associations and visibility-aware graph]
    H[Previous accepted state and uncertainty] --> E
    E --> F[Small spatial GNN plus causal temporal memory]
    F --> G[Calibrated reliability and evidence confidence]
    E --> R[Residual and sequential consistency checks]
    R --> G
    G --> I[Trust update with hysteresis]
    I --> J[Downweight or quarantine suspect reports]
    J --> K[Conservative track fusion]
    K --> L[Observability and ambiguity check]
    L --> M[Accepted tracks OR degraded / ambiguous output]
    M --> H
    M --> N[Replay display and audit logs]
    A --> O[Clean reference branch: offline evaluation only]
    GT[Annotations and injection manifest] --> Q[Offline metrics]
    O --> Q
    M --> Q
```

Annotations, attack labels, and the clean reference branch must never be accessible to the online detector. A useful test is to remove those files after preparing the replay input and verify identical inference output.

### Stage 1: canonical event format

Each report carries sensor ID, acquisition time, reception time if available, coordinate frame, range/bearing/radial velocity or transformed position, available quality fields, and validity flags. Never invent SNR or other fields absent from the dataset. Keep source hashes and preserve the untouched data.

Transform to a common local frame using calibrated poses. Propagate older observations to the processing epoch with uncertainty growth; never use future measurements to improve a past estimate. Reject stale or malformed records. Shared pose uncertainty must be acknowledged in consistency tests.

### Stage 2: causal local tracking

Use a small, documented clustering method and a Kalman/EKF tracker with state `[x, y, vx, vy]`, covariance, age, and missed-update count. Use nearest-neighbor/Hungarian association with gates as the initial implementation. Label this association algorithm separately from the neural graph model.

All methods receive the same attacked input and the same frontend. Avoid a different frontend for the proposed method that would confound the comparison. Learn or calibrate measurement-error settings from training recordings; label any heuristic covariance and test its sensitivity. Extended-object radar returns do not equal the bounding-box center; account for this in clustering, association gates, and error interpretation.

### Stage 3: graph construction

Use a node for each local sensor-track report, plus missing-observation nodes where a tracked target was plausibly observable. Add temporal links along local histories and cross-sensor links between candidate observations of the same object. Edge construction uses estimates and gates, never annotation track IDs. Preserve an unmatched candidate path so a manipulated report cannot disappear from monitoring simply because it falls outside an association gate.

Node features: normalized prediction residual, track covariance/age, recent changes, missed detections, timestamp age, point support, and available Doppler/RCS summaries. Edge features: relative state, time difference, geometric compatibility, visibility evidence, and uncertainty. Doppler values must be projected through each sensor's line of sight; equality of raw radial velocities is not the expected relation.

A useful sensor model is `z_i(t) = h_i(x(t), pose_i(t)) + noise_i(t) + attack_i(t)` for retained observations. Insertions and deletions modify the observation set rather than only this additive term.

### Stage 4: compact temporal GNN

Begin with two message-passing layers and one causal GRU, with small hidden dimensions chosen on validation. GraphSAGE-style aggregation with explicit edge features is sufficient for a first version; attention is optional, not automatically a trust score. Limit candidate edges and history length for Colab feasibility. Precompute frontend features to avoid repeatedly decoding the full dataset.

Produce a corruption probability per observation slot and a confidence/abstention signal. Train on known injected corruptions and clean/benign-stress examples; use no future frames. A coordination edge/class head is optional only if single-observation reliability is working. Ground-truth coalition labels belong to training/evaluation, not graph construction.

A graph is justified only if relational evidence improves held-out results beyond a per-node temporal model and a pooled set model. A five-node sensor-only graph may be too coarse for target-specific attacks, which is why track-level nodes are proposed.

### Stage 5: trust update

Calibrate model probabilities on validation data. Estimate reliability from model output and causal consistency evidence; use the same validation process for baseline detectors. A simple bounded update is `T_t = (1-alpha) T_(t-1) + alpha q_t`, where `q_t` is calibrated reliability and `alpha` controls memory. This is an engineering smoother, not a Bayesian posterior unless a probabilistic derivation is supplied.

Use faster trust reduction and slower recovery if validated; retain minimum evidence requirements and an unknown state when observations are missing. Do not use trust-weighted fused output to certify itself without qualification. Keep leave-one-sensor-out residual checks or independent local predictions, and report their limitations under shared corruption. Do not multiply correlated model and residual probabilities as though independent.

### Stage 6: fusion and mitigation

Quarantine clearly unreliable reports; downweight borderline ones by covariance inflation, for example `P_i_eff = P_i / max(T_i, epsilon)` for retained inputs. Tune epsilon and thresholds on validation. Low-trust streams should not accumulate unlimited weak votes.

For associated local states use covariance intersection:

`P_f^-1 = sum_i w_i (P_i_eff)^-1`

`x_f = P_f sum_i w_i (P_i_eff)^-1 x_i`, with `w_i >= 0` and `sum_i w_i = 1`.

Choose weights by a stated uncertainty criterion over admitted candidates. CI is conservative for suitable consistent inputs; arbitrary malicious bias and data-dependent selection invalidate any blanket consistency claim. Measure empirical coverage and error. Do not count the same fused prior as independent evidence in several local tracks.

If evidence supports two incompatible clusters with no trustworthy discriminator, retain alternatives or mark the target ambiguous. If no measurements remain, coast briefly using the motion model with increasing covariance, then mark the track stale. Predictions are not reconstructed observations. Restoration requires independent evidence, not a claim that the GNN can recover information that was entirely removed.

### Stage 7: logging and presentation

Display source observations, baseline tracks, protected tracks, covariance/uncertainty, trust histories, attack interval, and alert state. Clearly label injected attacks and offline reference overlays. Keep the attack label hidden from inference even if visible to the audience. Show source scene ID, code revision, model checksum, and run ID.

## 9. Attack and benign-stress experiment matrix

All test modifications occur offline or inside replay, not through RF transmission.

| Family | Controlled experiment | Question |
|---|---|---|
| Single-stream bias | Perturb one target's reports at one sensor | Can simple baselines already solve it? |
| Coordinated false trajectory | Project one plausible false world trajectory into several sensor report frames | Does consistent false agreement defeat the method? |
| Slow coordinated drift | Gradually displace reports within plausible kinematics | Does temporal detection add value over instantaneous gates? |
| Coordinated ghost | Add a matching false track to two or more eligible streams | Is false-track acceptance reduced? |
| Suppression | Remove a selected real object's reports in several streams | Is missing evidence distinguished from invisibility, and is track continuity preserved? |
| Intermittent corruption | Alternate corruption and clean periods | Does trust recovery allow repeated exploitation? |
| Benign faults | Timing jitter, dropout, calibration perturbation, natural clutter | Is the system confusing faults with intentional attacks? |
| Ambiguity boundary | Corrupt all useful observers or create balanced conflicting groups | Does the system admit uncertainty instead of displaying false certainty? |

For each, vary the fraction of **eligible observers of that target**, not just the fraction of all installed sensors. Test one, two, and more compromised streams only where coverage permits. Stratify by overlap and by attack severity relative to measured residual scales. Publish numerical units and final ranges; do not choose them after inspecting test results.

Generate coordinated displacement from one shared world-frame trajectory, then derive sensor-specific range/bearing/Doppler. Independently adding the same range offset to every radar is generally not geometrically coordinated. Keep inserted-point support and attributes within documented empirical bounds, while stating that plausibility is weaker than RF realizability.

Matched comparisons must include the same number of corrupted sensors and comparable attack magnitude for coordinated and uncoordinated cases. Use separate random seeds and trajectory templates for held-out attacks. A report-level replay with old timestamps tests protocol checks; a replay with updated timestamps tests semantic consistency. Keep those claims separate.

## 10. Baselines, ablations, and statistical validity

Minimum full-pipeline baselines:

1. Same tracker/fusion without attack protection.
2. Prediction innovation gate plus a sequential residual detector such as CUSUM.
3. Robust geometric consensus and hand-designed temporal trust, followed by the same fusion rule.
4. Per-node MLP/GRU detector without graph message passing, followed by the same trust/fusion.
5. Proposed temporal graph detector with trust/fusion.

Add a permutation-invariant pooled model if affordable. A faithful MATE reproduction is valuable only if code, assumptions, and time permit. Otherwise call a simplified adaptation “MATE-inspired” and document every change; never present it as a reproduction. An oracle that excludes injected corruptions provides a reference bound under the same remaining observations, not a deployable method.

Essential ablations: remove temporal memory; remove visibility handling; replace learned trust with fixed trust; compare trust downweighting with hard rejection; remove graph edges while keeping comparable model size. Prioritize the graph-vs-GRU and trust-vs-no-trust experiments if time is tight.

Split at scene/recording level **before** generating attacks, extracting overlapping windows, or fitting normalization. Keep nearby/repeated recordings grouped where possible. No clean scene and attacked version may appear across different splits. Fit noise scales, thresholds, calibration, and hyperparameters using training/validation only. Evaluate once on a frozen test manifest.

Report:

- Detection precision–recall curve/AUPRC, precision/recall/F1 at a validation-selected threshold, and false alerts per clean minute.
- Per-sensor/per-object localization errors and attack-event detection delay; count never-detected attacks explicitly rather than averaging only successes.
- Tracking position/velocity error for matched objects, false tracks, missed tracks, identity switches, and GOSPA where appropriate. GOSPA accounts for localization and cardinality error; fix its distance/cutoff/order settings before test. [Primary metric paper](https://arxiv.org/abs/1601.05585).
- Clean-data degradation, removal of honest measurements, confidence calibration, and fraction of time degraded/abstaining.
- End-to-end p50/p95 processing latency and memory on the actual measured hardware. Separate feature extraction, graph creation, neural inference, and fusion; GPU inference time alone is insufficient.

For nuScenes physical-position metrics, evaluate at annotation times and describe annotation limitations. For RadarScenes, distinguish clean-reference deviation from actual physical error. Never delete unmatched targets from RMSE reporting without also reporting missed/false-target metrics.

Run at least three training seeds if feasible, aiming for five for the final selected model. Compute paired confidence intervals by bootstrapping independent scenes, not highly correlated frames. Report number of scenes, objects, attack events, clean minutes, and excluded cases. Sample counts and confidence intervals must be produced by scripts, not entered manually. Use a balanced development set but report low attack-prevalence behavior as well.

Success is a measured tradeoff: lower attacked tracking error and false-track acceptance than the strongest feasible baseline, while preserving acceptable clean behavior and compute cost. Agree practical margins after the pilot and before final testing. If the graph model does not improve the tradeoff, report that honestly and retain the stronger simpler method in the demo.

## 11. Demonstration script

Use three selected, identified replay scenes, chosen by a stated rule rather than only the most impressive result:

1. **Normal scene:** show sensor streams, tracks, and stable trust. Demonstrate a benign missed observation without a false accusation.
2. **Coordinated manipulation:** replay the exact same recording with two eligible streams altered. Compare baseline and protected outputs. Show actual logged detection delay and error; do not prefill an expected improvement.
3. **Failure-boundary scene:** remove independent support or present consistent corruption across all useful observers. Show the ambiguity/degraded response and explain why truth cannot be recovered from absent evidence.

Provide a recorded fallback demonstration because free Colab sessions and GPUs are not guaranteed. Run the presentation from saved outputs or local CPU replay if live inference is too slow. Label playback speed separately from measured throughput. Freeze one deterministic demo configuration and retain full raw logs.

## 12. Calendar and two-person ownership

There are 24 calendar days from 7 November to 1 December. This is tight; avoid building raw RF processing, multiple full datasets, a large transformer, a custom simulator, or a complex web application.

| Dates | Person A: data, tracking, evaluation | Person B: literature, detector, writing | Exit condition |
|---|---|---|---|
| Nov 7–9 | Dataset access, mini replay, timestamp/coordinate checks, overlap audit | Literature matrix, exact threat model, baseline specifications | At least one real replay and measured coverage; otherwise activate fallback |
| Nov 10–12 | Local tracker, paired clean/attacked replay, residual baseline | Compact node-only model and graph feature design | Baseline errors and attacks logged; labels excluded from inference |
| Nov 13–16 | Robust fusion, conservative fallback, metric scripts | Temporal GNN, training checkpoints, validation calibration | First end-to-end result; no performance claims yet |
| Nov 17–20 | Freeze splits and test manifests; batch runs | Main comparisons, graph/temporal/trust ablations | Complete essential experiments; freeze model choices |
| Nov 21–24 | Confidence intervals, latency, failure-case audits | Manuscript results, related-work comparison, limitations | Tables regenerate from raw logs |
| Nov 25–27 | Deterministic demonstration and installation notes | Full manuscript draft and references | Reproducible package and complete draft |
| Nov 28–30 | Fresh-environment replay; fix defects | Supervisor review, claim/citation audit, venue formatting | Submission-ready paper and presentation |
| Dec 1 | Deliver frozen project, logs, demo recording | Deliver paper; submit only after author/supervisor checks | Completed research artifact; acceptance remains external |

Both members cross-review the other's data leakage and metric code. If no functional baseline exists by 12 November, reduce the number of attack families and keep one compact model. If no stable GNN result exists by 16 November, prioritize a rigorous baseline study and clearly label the learned component exploratory. Never substitute fabricated results for a missed milestone.

## 13. Implementation and compute plan

Use Python for ingestion, tracking, graph features, and metrics; PyTorch for the compact model. A graph package is optional because a small explicit edge-list message-passing implementation may reduce installation friction. Pin actual tested versions when implementation begins. Use notebooks only as entry points; keep core logic in importable modules and save configuration files.

Suggested structure:

```text
data_manifests/       # source version, hashes, scene splits; no redistributed raw data
src/data/            # adapters and causal transforms
src/tracking/        # common frontend and association
src/attacks/         # offline controlled report transformations
src/models/          # node-only and graph-temporal models
src/fusion/          # trust, conservative fusion, ambiguous states
src/evaluation/      # metrics and scene-level confidence intervals
configs/             # frozen configurations
experiments/         # run manifests, checkpoints, logs
demo/                # simple replay viewer and saved examples
paper/               # manuscript and generated tables/figures
```

Cache compact features for a subset that fits available storage. Checkpoint to persistent storage after each epoch/run. Use CPU baselines and short GPU training batches; do not design around a guaranteed GPU model or uninterrupted long session. Quantify resource limits from the pilot instead of inventing training times or hardware prices.

Minimum verification: coordinate/velocity consistency, no future-frame access, split separation, visibility handling, exact attack-label alignment, known-answer metrics on tiny examples, empty-observation behavior, and replay reproducibility. These tests directly protect scientific validity.

## 14. Publication plan and claims

Write the paper while running experiments: introduction and scope, closest related work, threat model/observability, method, data and injection protocol, baselines, results with uncertainty, failure cases, limitations, and reproducibility statement.

Choose a supervisor-approved radar, sensor-fusion, or intelligent-transportation venue after seeing the results. Verify the current call, deadlines, fees, review requirements, and scope on the official venue site before submission. This plan does not promise a specific acceptance or use an unverified upcoming deadline. A preprint is public dissemination, not peer-reviewed acceptance. Do not select an outlet because it promises publication within days.

Permissible claim after successful experiments:

> On the specified held-out driving recordings and report-level attack families, the evaluated detector/fusion pipeline changed the measured detection and tracking tradeoff relative to the stated baselines.

Impermissible claims from this design alone: universal attack detection; guaranteed protection of aviation or military radar; measured RF jamming resistance; real-world coordinated attack prevention; certified safety; or a physical attack dataset when the malicious part was injected in software.

The strongest possible deliverable by the deadline is an honest, reproducible result with a working demonstration, clear improvements where observed, and clear failure limits where recovery is impossible.

## 15. Immediate actions and unresolved evidence

Start with dataset access and the coverage audit, not model training. Retrieve the complete nearest-neighbor literature identified above, especially the inaccessible trust-aware fusion paper and GCN/Transformer paper. Confirm institutional dataset terms before downloading or redistributing any data. Save source versions and bibliographic metadata from the original publications rather than search snippets.

Outstanding questions for experimentation: how much eligible multi-radar overlap exists; how reliable local tracks are; which features survive benign calibration shifts; whether graph learning beats a GRU/robust residual baseline; and how often the system must abstain. These are research questions, not assumptions to hide.
